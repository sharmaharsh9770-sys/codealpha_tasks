# CodeAlpha Artificial Intelligence Internship — Tasks 1 & 2

## Task 1: Language Translation Tool
- Responsive interface with source and target language selectors.
- Text input and translated output.
- Uses the MyMemory Translation API.
- Includes language swap, clear and copy translation controls.
- Requires internet access to call the translation service.
- API usage may be limited; check the service's current terms before production use.

## Task 2: FAQ Chatbot
- Chat interface with suggested example questions.
- Includes a small sample FAQ knowledge base.
- Uses keyword overlap and a simple similarity score to match the closest FAQ.
- Returns the best-matching answer or a fallback when no close match is found.
- Runs locally in the browser; no backend or API key required.

## Run
Open `task1_language_translation_tool.html` and `task2_faq_chatbot.html` in a modern browser. Task 1 requires internet access; Task 2 runs offline.

## Customize
- Edit the `faqs` array in Task 2 to add questions, answers, and keywords relevant to your internship topic.
- For a production translation app, use a supported translation provider and protect any API keys on a backend rather than placing secret keys in client-side code.
